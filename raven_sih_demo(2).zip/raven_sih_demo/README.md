# Raven — Disaster Management System

A front-end Smart India Hackathon demo built with **HTML, CSS and vanilla JavaScript**.

## Features

- Command-center dashboard
- Leaflet + OpenStreetMap live map
- SOS workflow using browser Geolocation where available
- Simulated offline Bluetooth/peer messaging layer
- Weather + short-term rainfall panel
- Chart.js rainfall intensity chart
- Auto-refreshing danger-zone simulation
- Authority emergency broadcasts with localStorage persistence
- Unified live-data timeline
- Field responder reports with filtering
- Editable local operator profile + emergency contacts
- Responsive dark tactical UI

## Structure

```text
raven/
├── index.html
├── dashboard.html
├── map.html
├── sos.html
├── chat.html
├── broadcast.html
├── field-reports.html
├── profile.html
├── README.md
├── css/
│   ├── style.css
│   ├── dashboard.css
│   └── map.css
├── js/
│   ├── app.js
│   ├── data.js
│   ├── dashboard.js
│   ├── danger-zones.js
│   ├── rainfall.js
│   ├── weather.js
│   ├── sos.js
│   ├── map.js
│   ├── bluetooth-chat.js
│   ├── broadcast.js
│   ├── telemetry.js
│   └── profile.js
└── data/
    ├── mock-data.js
    └── data.js
```

## Run

For the best experience, use a local server because Geolocation and some browser APIs are restricted on `file://`.

### Python
```bash
cd raven
python -m http.server 5500
```
Then open `http://localhost:5500/dashboard.html`.

VS Code Live Server works too.

`index.html` is the landing redirect-style shell; the main demo starts at `dashboard.html`.

## External libraries

No application framework is used. The only external browser libraries are:
- Leaflet 1.9.4 via CDN for the map
- Chart.js 4.4.4 via CDN for the rainfall chart
- OpenStreetMap tiles for map data

An internet connection is required to load those CDN assets and map tiles.

## Demo / production boundary

The following are intentionally front-end simulations:
- Bluetooth peer discovery and message delivery
- Live backend feeds
- Weather prediction
- SOS transmission to authorities
- Broadcast delivery
- Field-report backend storage

For production, replace those modules with native Android/BLE transport, authenticated REST/WebSocket APIs, a weather service, a real emergency gateway, server-side persistence, and proper encryption/authentication.

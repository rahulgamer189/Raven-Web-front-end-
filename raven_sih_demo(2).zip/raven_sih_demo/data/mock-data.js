// Replace these objects with API/WebSocket responses later.
window.RAVEN_DATA = {
  weather:{temp:29,feels:31,condition:"Partly cloudy",humidity:78,wind:18,rainChance:72,forecast:[
    {day:"NOW",icon:"⛅",temp:"29°",rain:"72%"},
    {day:"+3H",icon:"🌧",temp:"27°",rain:"84%"},
    {day:"+6H",icon:"⛈",temp:"26°",rain:"91%"}]},
  zones:[
    {id:1,name:"Mahanadi Floodplain",risk:"Critical",level:94,lat:20.2961,lng:85.8245,meta:"River level rising"},
    {id:2,name:"Old Town Sector",risk:"High",level:77,lat:20.258, lng:85.84,meta:"Waterlogging reported"},
    {id:3,name:"Airport Corridor",risk:"Medium",level:48,lat:20.252, lng:85.817,meta:"Heavy rainfall"},
    {id:4,name:"Patia Safe Grid",risk:"Low",level:15,lat:20.354, lng:85.819,meta:"Operational"}],
  sos:[
    {id:"S-104",name:"SOS-104",lat:20.291,lng:85.835,status:"Unverified"},
    {id:"S-105",name:"SOS-105",lat:20.276,lng:85.851,status:"Responder assigned"}],
  shelters:[
    {name:"Raven Shelter A",lat:20.312,lng:85.817,capacity:220},
    {name:"Community Hall B",lat:20.337,lng:85.846,capacity:140}],
  nearby:[
    {id:"NODE-07",name:"Responder 07",distance:"18 m",online:true},
    {id:"NODE-12",name:"Raven Volunteer",distance:"42 m",online:true},
    {id:"NODE-21",name:"Field Unit 21",distance:"87 m",online:false},
    {id:"NODE-31",name:"Medical Team",distance:"124 m",online:true}],
  broadcasts:[
    {id:"B-221",title:"FLASH FLOOD WARNING",message:"Residents near low-lying river corridors should move to designated shelters.",severity:"Critical",area:"Mahanadi corridor",time:"2 min ago"},
    {id:"B-220",title:"Heavy rainfall advisory",message:"Avoid unnecessary travel and monitor local evacuation notices.",severity:"High",area:"Bhubaneswar",time:"18 min ago"}],
  reports:[
    {id:"FR-88",location:"Unit-4 Junction",condition:"Road partially submerged; traffic slow.",resources:"Rescue vehicle",severity:"High",time:"6 min ago"},
    {id:"FR-87",location:"Patia",condition:"Shelter operational; water and first aid stocked.",resources:"None",severity:"Low",time:"21 min ago"}],
  feed:[
    {type:"SOS",title:"New SOS signal received",body:"SOS-105 • Responder assigned",time:"NOW"},
    {type:"WEATHER",title:"Rainfall intensity rising",body:"Current estimate 18 mm/hr",time:"1 min"},
    {type:"BROADCAST",title:"Authority broadcast",body:"Flash flood warning issued",time:"2 min"},
    {type:"FIELD",title:"Field report received",body:"Unit-4 Junction • Rescue vehicle requested",time:"6 min"}]
};

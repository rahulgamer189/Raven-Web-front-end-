// Alias file kept for the requested data/ folder structure.
// The app loads data/mock-data.js through js/data.js in the demo pages.

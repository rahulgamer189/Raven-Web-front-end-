const defaultProfile={name:"Raven Operator",role:"Responder",phone:"+91 90000 00000",email:"operator@raven.demo",location:"Bhubaneswar, Odisha",contacts:[{name:"Emergency Contact",phone:"+91 90000 00001"}]};
function getProfile(){return JSON.parse(localStorage.getItem("raven_profile")||"null")||defaultProfile}
function renderProfile(){
 const p=getProfile(),f=document.getElementById("profile-form");if(!f)return;
 ["name","role","phone","email","location"].forEach(k=>{if(f.elements[k])f.elements[k].value=p[k]||""});
 document.getElementById("profile-name-heading").textContent=p.name||"Raven operator";
 const el=document.getElementById("contacts");el.innerHTML=(p.contacts||[]).map((c,i)=>`<div class="contact-row"><input data-contact-name="${i}" value="${c.name||""}" placeholder="Name"><input data-contact-phone="${i}" value="${c.phone||""}" placeholder="Phone"><button type="button" class="contact-remove" data-remove="${i}">×</button></div>`).join("");
 el.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{const p=getProfile();p.contacts.splice(Number(b.dataset.remove),1);localStorage.setItem("raven_profile",JSON.stringify(p));renderProfile()}));
}
function collectContacts(){return [...document.querySelectorAll("[data-contact-name]")].map((x,i)=>({name:x.value,phone:document.querySelector(`[data-contact-phone="${i}"]`)?.value||""}))}
document.addEventListener("DOMContentLoaded",()=>{
 renderProfile();document.getElementById("add-contact")?.addEventListener("click",()=>{const p=getProfile();p.contacts.push({name:"",phone:""});localStorage.setItem("raven_profile",JSON.stringify(p));renderProfile()});
 document.getElementById("profile-form")?.addEventListener("submit",e=>{e.preventDefault();const p=getProfile(),f=e.target;["name","role","phone","email","location"].forEach(k=>p[k]=f.elements[k].value);p.contacts=collectContacts();localStorage.setItem("raven_profile",JSON.stringify(p));renderProfile();alert("Profile saved locally.")});
});
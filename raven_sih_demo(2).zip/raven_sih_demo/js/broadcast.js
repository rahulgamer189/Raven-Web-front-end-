function getBroadcasts(){return JSON.parse(localStorage.getItem("raven_broadcasts")||"null")||window.RAVEN_DATA.broadcasts}
function saveBroadcast(b){const list=getBroadcasts();list.unshift(b);localStorage.setItem("raven_broadcasts",JSON.stringify(list.slice(0,30)));return list}
function renderBroadcastHistory(){
 const el=document.getElementById("broadcast-history");if(!el)return;
 el.innerHTML=getBroadcasts().map(b=>`<div class="feed-item"><div class="feed-time">${b.time}</div><div class="feed-body"><strong>${b.title} <span class="risk risk-${b.severity.toLowerCase()}">${b.severity}</span></strong><span>${b.message}</span><small>${b.area}</small></div></div>`).join("");
}
function renderLatestBroadcast(){
 const el=document.getElementById("latest-broadcast");if(!el)return;
 const b=getBroadcasts()[0];el.innerHTML=b?`<div class="latest"><h3>${b.title}</h3><p>${b.message}</p><small>${b.area} • ${b.time} • ${b.severity}</small></div>`:"<p class='muted'>No active broadcast.</p>";
}
document.addEventListener("DOMContentLoaded",()=>{
 renderBroadcastHistory();renderLatestBroadcast();
 const f=document.getElementById("broadcast-form");if(f)f.addEventListener("submit",e=>{
   e.preventDefault();const d=new FormData(f);saveBroadcast({id:"B-"+Date.now(),title:d.get("title"),message:d.get("message"),severity:d.get("severity"),area:d.get("area"),time:"JUST NOW"});f.reset();renderBroadcastHistory();renderLatestBroadcast();
 });
});
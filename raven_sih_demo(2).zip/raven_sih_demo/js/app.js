/* Raven shell: shared navigation + emergency banner + global live clock. */
(function(){
  const page=document.body.dataset.page||"dashboard";
  const nav=[
    ["dashboard.html","Dashboard","dashboard"],
    ["map.html","Live Map","map"],
    ["broadcast.html","Broadcast","broadcast"],
    ["field-reports.html","Reports","reports"],
    ["profile.html","Profile","profile"]
  ];
  const shell=document.getElementById("app-shell");
  if(!shell)return;
  shell.innerHTML=`
    <header class="topbar">
      <a class="brand" href="dashboard.html"><span class="brand-mark">R</span> RAVEN</a>
      <nav class="nav" aria-label="Primary">${nav.map(n=>`<a class="${page===n[2]?"active":""}" href="${n[0]}">${n[1]}</a>`).join("")}</nav>
    </header>
    <div id="site-alert" style="display:none"></div>`;
  document.addEventListener("click",e=>{
    const a=e.target.closest("#global-sos");
    if(a){e.preventDefault();location.href="sos.html";}
  });
})();
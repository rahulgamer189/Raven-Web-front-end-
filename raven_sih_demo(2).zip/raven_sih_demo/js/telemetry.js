function getReports(){return JSON.parse(localStorage.getItem("raven_reports")||"null")||window.RAVEN_DATA.reports}
function saveReport(r){const list=getReports();list.unshift(r);localStorage.setItem("raven_reports",JSON.stringify(list.slice(0,50)))}
function renderReports(){
 const el=document.getElementById("reports-list");if(!el)return;
 const filter=document.getElementById("report-filter")?.value||"all";
 const list=getReports().filter(r=>filter==="all"||r.severity===filter);
 el.innerHTML=list.map(r=>`<article class="report"><div class="report-top"><strong>${r.location}</strong><span class="risk risk-${r.severity.toLowerCase()}">${r.severity}</span></div><p>${r.condition}</p><small>${r.resources||"No resource request"} • ${r.time}</small></article>`).join("")||"<p class='muted'>No reports match the filter.</p>";
}
document.addEventListener("DOMContentLoaded",()=>{
 renderReports();document.getElementById("report-filter")?.addEventListener("change",renderReports);
 document.getElementById("report-form")?.addEventListener("submit",e=>{
  e.preventDefault();const d=new FormData(e.target);saveReport({id:"FR-"+Date.now(),location:d.get("location"),condition:d.get("condition"),resources:d.get("resources"),severity:d.get("severity"),time:"JUST NOW"});e.target.reset();renderReports();
 });
});
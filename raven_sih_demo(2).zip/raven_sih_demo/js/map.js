let ravenMap,layers={zones:L.layerGroup(),sos:L.layerGroup(),shelters:L.layerGroup(),rain:L.layerGroup()};
function initMap(){
 const mapEl=document.getElementById("map");if(!mapEl||!window.L)return;
 ravenMap=L.map(mapEl).setView([20.2961,85.8245],12);
 L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"© OpenStreetMap contributors",maxZoom:19}).addTo(ravenMap);
 Object.values(layers).forEach(x=>x.addTo(ravenMap));
 const zIcon=r=>L.divIcon({className:"",html:`<div style="width:18px;height:18px;border-radius:50%;background:${r==="Critical"?"#ff3d00":r==="High"?"#ff9100":r==="Medium"?"#ffd740":"#00e676"};box-shadow:0 0 16px currentColor;border:2px solid #fff"></div>`,iconSize:[18,18],iconAnchor:[9,9]});
 window.RAVEN_DATA.zones.forEach(z=>L.marker([z.lat,z.lng],{icon:zIcon(z.risk)}).bindPopup(`<b>${z.name}</b><br>Risk: ${z.risk}<br>${z.meta}`).addTo(layers.zones));
 window.RAVEN_DATA.sos.forEach(s=>L.marker([s.lat,s.lng]).bindPopup(`<b>${s.name}</b><br>${s.status}`).addTo(layers.sos));
 window.RAVEN_DATA.shelters.forEach(s=>L.marker([s.lat,s.lng]).bindPopup(`<b>${s.name}</b><br>Capacity: ${s.capacity}`).addTo(layers.shelters));
 if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>L.circleMarker([p.coords.latitude,p.coords.longitude],{radius:9,color:"#00e676",fillColor:"#00e676",fillOpacity:.8}).bindPopup("<b>Your location</b>").addTo(ravenMap),()=>{});
 document.querySelectorAll("[data-layer]").forEach(c=>c.addEventListener("change",()=>{const layer=layers[c.dataset.layer];if(!layer)return;c.checked?layer.addTo(ravenMap):ravenMap.removeLayer(layer)}));
 const stats=document.getElementById("map-stats");if(stats)stats.innerHTML=`<div class="data-grid"><div class="data-item"><span>Zones</span><b>${window.RAVEN_DATA.zones.length}</b></div><div class="data-item"><span>SOS</span><b>${window.RAVEN_DATA.sos.length}</b></div><div class="data-item"><span>Shelters</span><b>${window.RAVEN_DATA.shelters.length}</b></div><div class="data-item"><span>Nodes</span><b>${window.RAVEN_DATA.nearby.length}</b></div></div>`;
 setInterval(()=>{document.getElementById("map-time").textContent=new Date().toLocaleTimeString()},1000);
}
document.addEventListener("DOMContentLoaded",initMap);
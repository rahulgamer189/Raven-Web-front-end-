function renderWeather(targetId="weather-panel"){
  const w=window.RAVEN_DATA.weather, el=document.getElementById(targetId); if(!el)return;
  el.innerHTML=`<div class="weather-main"><div><div class="weather-temp">${w.temp}°</div><div class="muted">${w.condition} • feels ${w.feels}°</div></div><div class="weather-icon">⛅</div></div>
  <div class="data-grid"><div class="data-item"><span>Humidity</span><b>${w.humidity}%</b></div><div class="data-item"><span>Wind</span><b>${w.wind} km/h</b></div><div class="data-item"><span>Rain chance</span><b>${w.rainChance}%</b></div><div class="data-item"><span>Rainfall</span><b id="rain-now">18 mm/hr</b></div></div>
  <div class="forecast">${w.forecast.map(x=>`<div><span>${x.day}</span><b>${x.icon} ${x.temp}</b><span>Rain ${x.rain}</span></div>`).join("")}</div>`;
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",()=>renderWeather());else renderWeather();
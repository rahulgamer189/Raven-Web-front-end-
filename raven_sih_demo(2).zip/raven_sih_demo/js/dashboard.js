function renderMetrics(){
 const el=document.getElementById("metrics");if(!el)return;
 const z=window.RAVEN_DATA.zones,s=window.RAVEN_DATA.sos;
 el.innerHTML=[
  ["CRITICAL ZONES",z.filter(x=>x.risk==="Critical").length,"Immediate attention"],
  ["ACTIVE SOS",s.length,"Signals in network"],
  ["RAIN INTENSITY","18 mm/hr","↑ 12% vs 30 min"],
  ["SHELTER CAPACITY","360","Across 2 safe zones"]
 ].map(x=>`<div class="metric"><div class="metric-label">${x[0]}</div><div class="metric-value">${x[1]}</div><div class="metric-sub">${x[2]}</div></div>`).join("");
}
function renderFeed(){
 const el=document.getElementById("live-feed");if(!el)return;
 el.innerHTML=window.RAVEN_DATA.feed.map(x=>`<div class="feed-item"><div class="feed-time">${x.time}</div><div class="feed-body"><strong>${x.title}</strong><span>${x.body}</span></div></div>`).join("");
}
document.addEventListener("DOMContentLoaded",()=>{renderMetrics();renderFeed();});